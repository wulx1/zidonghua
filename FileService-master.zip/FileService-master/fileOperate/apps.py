from django.apps import AppConfig


class FileoperateConfig(AppConfig):
    name = 'fileOperate'
